package Monopoly;

public interface IDie
{
    public void roll();
    public int getFaceValue();
}

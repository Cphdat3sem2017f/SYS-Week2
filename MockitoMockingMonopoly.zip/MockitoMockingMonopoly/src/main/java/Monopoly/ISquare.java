package Monopoly;

public interface ISquare
{
    
}

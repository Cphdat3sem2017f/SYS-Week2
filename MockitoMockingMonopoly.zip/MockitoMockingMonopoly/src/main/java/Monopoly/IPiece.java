package Monopoly;

public interface IPiece
{
    public ISquare getLocation();
    public void setLocation(ISquare newLoc);
}

package Monopoly;

public interface IBoard
{
    public ISquare getSquare(ISquare oldLoc, int fvTot);
}

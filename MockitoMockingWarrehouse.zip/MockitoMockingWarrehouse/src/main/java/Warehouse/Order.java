package Warehouse;

public class Order
{
        private int number;
        private String product;
        private boolean filled;
        IWarehouse warehouse;

    public Order(int number, String product, IWarehouse warehouse)
    {
        this.number = number;
        this.product = product;
        this.warehouse = warehouse;
    }
        
       public void fill()
       {
           int inventory = warehouse.getInventory(product);
           if(inventory >= number)
           {
               warehouse.setNumber(inventory-number);
               filled = true;
           }
       }
       
       public boolean isFilled()
       {
           return filled;
       }
}

package Warehouse;

public interface IWarehouse
{
    public int getInventory(String product);
    public boolean setNumber(int number);
}

package Warehouse;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import org.mockito.InOrder;
import org.mockito.Mock;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import org.mockito.junit.MockitoJUnitRunner;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.inOrder;

@RunWith(MockitoJUnitRunner.class) 
public class OrderTest
{
    private final int NUMBER = 50;
    private final String PRODUCT = "Rum";
    private final int INVENTORY = 100;
    
    @Mock
    private IWarehouse mockWarehouse;

    
    public OrderTest()
    {
    }
    
    @BeforeClass
    public static void setUpClass()
    {
    }
    
    @AfterClass
    public static void tearDownClass()
    {
    }
    
    @Before
    public void setUp()
    {
    }
    
    @After
    public void tearDown()
    {
    }

    /**
     * Test of fill method, of class Order.
     */
    @Test
    public void testFill()
    {
        //Initialize mock object
        mockWarehouse = mock(IWarehouse.class);
        Order order = new Order(NUMBER, PRODUCT, mockWarehouse);
        
        // setup expectations about collaborating behavior      
	InOrder inOrder = inOrder(mockWarehouse);
        when(mockWarehouse.getInventory(PRODUCT)).thenReturn(INVENTORY);
	when(mockWarehouse.setNumber(INVENTORY-NUMBER)).thenReturn(Boolean.TRUE);

        // execute test
	order.fill();
	boolean isFilled = order.isFilled();
        
        //Verify State
        assertTrue(isFilled);
        //verify behaviour
        inOrder.verify(mockWarehouse, times(1)).getInventory(PRODUCT);
        inOrder.verify(mockWarehouse, times(1)).setNumber(INVENTORY-NUMBER);


    }
    
}
